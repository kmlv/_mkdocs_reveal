<script type="text/x-mathjax-config">
    MathJax.Hub.Config({
      tex2jax: {
  	  inlineMath: [ ['$','$'], ["\\(","\\)"] ],
	  displayMath: [ ['$$','$$'], ["\\[","\\]"] ],
	  processEscapes: true,
	  displaystyle: true
      },
      "HTML-CSS": { availableFonts: ["TeX"] }
    });
  </script><script type="text/javascript"
    src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML-full">
  </script>